local function object_entry(data)
 dependency 'object-loader'
this_is_a_map 'yes'
 file(data)
 object_file(data)
end

object_entry 'praça.xml'

local function object_entry(data)
 dependency 'object-loader'

 file(data)
 object_file(data)
end